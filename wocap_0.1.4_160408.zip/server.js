
// это в джсон? массив массивов.
var messages = ['Hello!', 'I kill you!', 'Not bad!', 'Worst turn!']



/////////////////////
var express = require('express'),
		app = express(app),
		server = require('http').createServer(app);

// server static files from current directory
app.use(express.static(__dirname));

//get eureca server class
var EurecaServer = require('eureca.io').EurecaServer;

//create an instance of EurecaServer
var eurecaServer = new EurecaServer({allow:['setId', 'spawnEnemy', 'kill', 'testRemote', 'loginAnswer', 'newGame', 'chat', 'getMarkers', 'ungetMarkers', 'getFigureMove', 'getFigureAttack']});
var clients = {};

// ОЧЕРЕДЬ
var clientsWait = [];

// ИГРЫ
var games = [];

//attach eureca.io to my http server
eurecaServer.attach(server);

/////////////////////
// MYSQL connect
/////////////////////
var mysql = require('mysql');
var dbConnection = mysql.createConnection({
  host     : 'localhost',
  user     : 'user',
  password : '1234',
  database : 'wocapdb0'
});

dbConnection.connect;

dbConnection.query('SELECT * from users', function(err, rows, fields) {
  if (!err)
    console.log('DataBase Connection done');
  else
    console.log('Error while performing Query.');
});




/////////////////////
//detect client connection
///////////////////// 
eurecaServer.onConnect( function (conn) {
	// body...
	console.log('New Client id=%s ', conn.id, conn.remoteAdress);

	//the getClient method provide a proxy allowing us to call remote client functions
    var remote = eurecaServer.getClient(conn.id);    
	//console.log(remote);
	//register the client
	clients[conn.id] = {id:conn.id, remote:remote}
		
	//call test
	remote.testRemote(conn.id);

	//here we call setId (defined in the client side)
	remote.setId(conn.id);
	

});

/////////////////////
// плаер стэйт
/////////////////////
eurecaServer.exports.playerState = function(con, state){
	var remote = eurecaServer.getClient(con);
	clients[con].state = state;
	var id = con;
	console.log('Client id = ' + con + ' : ' + clients[con].state);
	
	if(clients[con].state == 'login'){
		clients[con].baseId = null;
	}
	
	if(clients[con].state == 'wait') {
		playerChekOponent(id);
	}
}

/////////////////////
//  ОЧЕРЕДЬ И БАЛАНСЕР
/////////////////////
function playerChekOponent(id){
	if(clientsWait.length>0){
		//	BALANCER

		//	CREATE PvP
		createGame(clients[id].id, clientsWait[0].id);
		delete clientsWait[0];
		sortAndClean();


	} else {		
		clientsWait.push(clients[id]);
	}



	for(var i=0; i<clientsWait.length; i+=1){

	}
	
}

/////////////////////
// НОВАЯ ИГРА
/////////////////////
function createGame(id1, id2){
	games[id1+id2] = new Game(id1, id2);

	//	fixme вытяаскивать из БД стэк игрока
	GenerateFigures(games[id1+id2], id1, 'A:4');//генерим для первого игрока
	GenerateFiguresPawn(games[id1+id2], id1, 'B:1');//генерим для первого игрока

	GenerateFigures(games[id1+id2], id2, 'D:2');//генерим для не первого игрока
	GenerateFiguresPawn(games[id1+id2], id2, 'D:3');//генерим для не первого игрока
	
	var remote =  eurecaServer.getClient(id1);
	remote.newGame(id1+id2, id2, games[id1+id2].field, games[id1+id2].turn, games[id1+id2].figure);
	
	remote = eurecaServer.getClient(id2);
	remote.newGame(id1+id2, id1, games[id1+id2].field, games[id1+id2].turn, games[id1+id2].figure);
	
}

var Game = function(id1, id2){
	this.id = id1+id2;
	this.id1 = id1;
	this.id2 = id2;
	this.turn = id1;
	this.field = new GenerateField(5, 4); // fixme юзеры выбирают размер
	this.figure = [];//new GenerateFigures(id1, id2);
	this.figureOnClick = null; // записываем индекс кликнутой фигуры сюда.
	
	// ФИГУРЫ
	//for(var i=1; i<=this.field.w){
	//}
}

////////////////////
// ГЕНЕРАЦИЯ ПОЛЯ
/////////////////////
var GenerateField = function(w, h){
	this.w = w;
	this.h = h;
	this.tile = [];

	// старты генерить надо где-то не тут

	for(var hh=1; hh<=this.h; hh+=1){//СТОЛБЦЫ
		for(var ww=1; ww<=this.w; ww+=1){//СТРОКИ
			var num = (hh-1)*w + ww;
			this.tile[num] = {};
			this.tile[num].inx = num;
			this.tile[num].coord = String.fromCharCode(64+hh);
			this.tile[num].coord += ':' + ww.toString();
			this.tile[num].vacant = null;
			this.tile[num].figInx = null;
			this.tile[num].type = 'tileStone'; //fixme брать из базы степь, лес, проч (см заметку в айфоне)
			this.tile[num].info = 'Информация'; //fixme too
			this.tile[num].bonus = 'пока хз как реализовать, видимо тупo CASE';

			//console.log(this.tile[num].coord);
		}
		//...
	}
}

/////////////////////
// ФИГУРЫ
/////////////////////
var GenerateFigures = function(gm, idd, crd){
	//для каждого генерим по очереди
	// fixme видимо будем всё брать из базы. Если это король - ставим на поле, остальных в резерв
	gm.figure.push({});
	// инфа 
	gm.figure[gm.figure.length-1].inx = gm.figure.length-1;
	gm.figure[gm.figure.length-1].id = idd;
	gm.figure[gm.figure.length-1].type = 'king'; // спрайт
	gm.figure[gm.figure.length-1].coord = crd; //фигура на поле, else '0:0'
	if(gm.figure[gm.figure.length-1].coord != '0:0'){
		toggleVacant(gm.id, gm.figure[gm.figure.length-1].coord, idd, gm.figure.length-1);
	}
	gm.figure[gm.figure.length-1].lifeTime = 50000; //уменьшаем каждый ход если ==0, писец фигуре
	gm.figure[gm.figure.length-1].friendBonusActive = 'health'; // тыкаем на своих
	gm.figure[gm.figure.length-1].friendBonusActiveMatrix = 'O'; // тыкаем на своих везде? ненужный аттрибут
	gm.figure[gm.figure.length-1].friendBonusPassive = 'health'; // стоим рядом
	gm.figure[gm.figure.length-1].onClick = false; 
	// ттх		
	gm.figure[gm.figure.length-1].cost = 1000000;
	gm.figure[gm.figure.length-1].attack = 1;
	gm.figure[gm.figure.length-1].health = 9;
	gm.figure[gm.figure.length-1].moveRadius = 10; //fixme ballancer, plz
	gm.figure[gm.figure.length-1].moveMatrix = 'O'; 
	// ттх бонусы
	gm.figure[gm.figure.length-1].costMult = 1;
	gm.figure[gm.figure.length-1].attackPlus = 0;
	gm.figure[gm.figure.length-1].attackMult = 1;
	gm.figure[gm.figure.length-1].healthPlus = 0;
	gm.figure[gm.figure.length-1].healthMult = 1;
}

// убрать потом это вот
var GenerateFiguresPawn = function(gm, idd, crd){
	//для каждого генерим по очереди
	// fixme видимо будем всё брать из базы. Если это король - ставим на поле, остальных в резерв
	gm.figure.push({});
	// инфа 
	gm.figure[gm.figure.length-1].inx = gm.figure.length-1;
	gm.figure[gm.figure.length-1].id = idd;
	gm.figure[gm.figure.length-1].type = 'pawn'; // спрайт
	gm.figure[gm.figure.length-1].coord = crd; //фигура на поле, else '0:0'
	if(gm.figure[gm.figure.length-1].coord != '0:0'){
		toggleVacant(gm.id, gm.figure[gm.figure.length-1].coord, idd, gm.figure.length-1);
	}
	gm.figure[gm.figure.length-1].lifeTime = 50000; //уменьшаем каждый ход если ==0, писец фигуре
	gm.figure[gm.figure.length-1].friendBonusActive = 'health'; // тыкаем на своих
	gm.figure[gm.figure.length-1].friendBonusActiveMatrix = 'I'; // тыкаем на своих везде? ненужный аттрибут
	gm.figure[gm.figure.length-1].friendBonusPassive = 'none'; // нихуа
	gm.figure[gm.figure.length-1].onClick = false; 
	// ттх		
	gm.figure[gm.figure.length-1].cost = 1;
	gm.figure[gm.figure.length-1].attack = 1;
	gm.figure[gm.figure.length-1].health = 2;
	gm.figure[gm.figure.length-1].moveRadius = 2; //fixme ballancer, plz
	gm.figure[gm.figure.length-1].moveMatrix = 'I'; 
	// ттх бонусы
	gm.figure[gm.figure.length-1].costMult = 1;
	gm.figure[gm.figure.length-1].attackPlus = 0;
	gm.figure[gm.figure.length-1].attackMult = 1;
	gm.figure[gm.figure.length-1].healthPlus = 0;
	gm.figure[gm.figure.length-1].healthMult = 1;
}

// клик
eurecaServer.exports.activateFigure = function(gId, idd, inx){
	
	var remote =  eurecaServer.getClient(idd);

	//проверка хода
	if(idd != games[gId].turn){
		return;
	}

	// сначала деактивация активной фигуры (усли таковая есть) 
	if(games[gId].figureOnClick == inx){
		remote.ungetMarkers();
		games[gId].markers.length = 0;
		games[gId].figureOnClick = null;
		return;
	}

	//console.log('create markers');
	
	var fig = games[gId].figure[inx];
	games[gId].figureOnClick = inx;

	if(!games[gId].markers){
		games[gId].markers = [];
	}
	games[gId].markers.length = 0;


	if(fig.coord == '0:0'){ //фигура не на поле. предлагаем спаун в первую линию
		//...
	} else { // иначе смотрим матрицу движения
		switch (fig.moveMatrix) { // кто блять придумал синтаксис свитча? ни раздела строк, нихуя бля! чорт ногу сломит
			case 'O': 
				moveMatrixO(gId, fig, games[gId].markers)
				break
			case 'X': 
				break
			case 'I': 
				moveMatrixI(gId, fig, games[gId].markers)
				break
			case 'F': 
				break
		}
	}

	remote.getMarkers(games[gId].markers);

	
}

//////////////////////////////////////
//	MOVE MATRIX матрица хода
//////////////////////////////////////

//  матрица хода О
function moveMatrixO(gId, fig, result){
	var ww = games[gId].field.w;
	var hh = games[gId].field.h;
	
	//var num = coord_toInx(fig.coord, ww, hh);

	if(fig.coord.length>3){
		var gorz=parseInt(fig.coord[2]+fig.coord[3], 10);
	} else {
		var gorz=parseInt(fig.coord[2], 10);
	}

	var vert =  fig.coord[0].charCodeAt(0)-64;


	//	fixme много одинакового кодаа! Зафигачить фцию и нырять в неё
	for(var rr = 1; rr<= fig.moveRadius; rr+=1){ 
		if(gorz+rr <= ww){//справа
			result.push({});
			result[result.length-1].coord = (fig.coord[0] + ':' + (gorz+rr).toString());
			if( games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == null){//fixme вывести в консоль и глянуть 
				result[result.length-1].type = 'move';
				result[result.length-1].vector = 'r';//для передвижения этот параметр не обязателен. только для атаки/помогаки
				if(fig.id == games[gId].id1){
					result[result.length-1].angle = 90;					
				} else if(fig.id == games[gId].id2){
					result[result.length-1].angle = 270;
				}
			} else if(games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == fig.id) {
				result[result.length-1].type = 'support'; 
				result[result.length-1].vector = 'r';
				break;
			} else {
				result[result.length-1].type = 'attack';
				result[result.length-1].vector = 'r';
				break;
			}
		}
	}

	for(var rr = 1; rr<= fig.moveRadius; rr+=1){ 
		if(gorz-rr >= 1){//слева
			result.push({});
			result[result.length-1].coord = (fig.coord[0] + ':' + (gorz-rr).toString());
			if( games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == null){//пиздец каой
				result[result.length-1].type = 'move';
				result[result.length-1].vector = 'l';
				if(fig.id == games[gId].id1){
					result[result.length-1].angle = 270;					
				} else if(fig.id == games[gId].id2){
					result[result.length-1].angle = 90;
				} 
			} else if(games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == fig.id) {
				result[result.length-1].type = 'support'; 
				result[result.length-1].vector = 'l';
				break;
			} else {
				result[result.length-1].type = 'attack';
				result[result.length-1].vector = 'l';
				break;
			}
		}
	}

	for(var rr = 1; rr<= fig.moveRadius; rr+=1){ 
		if(vert+rr <= hh){//сверху
			result.push({});
			result[result.length-1].coord = (String.fromCharCode(64+vert+rr) + ':' + gorz.toString());
			if( games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == null){//пиздец каой
				result[result.length-1].type = 'move';
				result[result.length-1].vector = 'u';
				if(fig.id == games[gId].id1){
					result[result.length-1].angle = 0;					
				} else if(fig.id == games[gId].id2){
					result[result.length-1].angle = 180;
				}
			}else if(games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == fig.id) {
				result[result.length-1].type = 'support'; 
				result[result.length-1].vector = 'u';
				break;
			} else {
				result[result.length-1].type = 'attack';
				result[result.length-1].vector = 'u';
				break;
			}
		}
	}

	for(var rr = 1; rr<= fig.moveRadius; rr+=1){ 
		if(vert-rr >= 1){//снизу
			result.push({});
			result[result.length-1].coord = (String.fromCharCode(64+vert-rr) + ':' + gorz.toString());
			if( games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == null){//пиздец каой
				result[result.length-1].type = 'move';
				result[result.length-1].vector = 'd';
				if(fig.id == games[gId].id1){
					result[result.length-1].angle = 180;					
				} else if(fig.id == games[gId].id2){
					result[result.length-1].angle = 0;
				}
			}else if(games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == fig.id) {
				result[result.length-1].type = 'support'; 
				result[result.length-1].vector = 'd';
				break;
			} else {
				result[result.length-1].type = 'attack';
				result[result.length-1].vector = 'd';
				break;
			}
		}
	}

	//диагональ 
	for(var rr = 1; rr<= fig.moveRadius; rr+=1){
		if(gorz+rr <= ww && vert+rr <= hh){//справа верх
			result.push({});
			result[result.length-1].coord = String.fromCharCode(64+vert+rr) + ':' + (gorz+rr).toString();
			if( games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == null){//пиздец каой
				result[result.length-1].type = 'move';
				result[result.length-1].vector = 'ru';
				if(fig.id == games[gId].id1){
					result[result.length-1].angle = 45;					
				} else if(fig.id == games[gId].id2){
					result[result.length-1].angle = 225;
				}
			}else if(games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == fig.id) {
				result[result.length-1].type = 'support'; 
				result[result.length-1].vector = 'ru';
				break;
			} else {
				result[result.length-1].type = 'attack';
				result[result.length-1].vector = 'ru';
				break;
			}
		}
	}

	for(var rr = 1; rr<= fig.moveRadius; rr+=1){
		if(gorz-rr >= 1 && vert+rr <= hh){//слева верх
			result.push({});
			result[result.length-1].coord = String.fromCharCode(64+vert+rr) + ':' + (gorz-rr).toString();
			if( games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == null){//пиздец каой
				result[result.length-1].type = 'move';
				result[result.length-1].vector = 'lu';
				if(fig.id == games[gId].id1){
					result[result.length-1].angle = 315;					
				} else if(fig.id == games[gId].id2){
					result[result.length-1].angle = 135;
				}
			}else if(games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == fig.id) {
				result[result.length-1].type = 'support'; 
				result[result.length-1].vector = 'lu';
				break;
			} else {
				result[result.length-1].type = 'attack';
				result[result.length-1].vector = 'lu';
				break;
			}
		}
	}

	for(var rr = 1; rr<= fig.moveRadius; rr+=1){
		if(gorz-rr >= 1 && vert-rr >= 1){//слева низ
			result.push({});
			result[result.length-1].coord = String.fromCharCode(64+vert-rr) + ':' + (gorz-rr).toString();
			if( games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == null){//пиздец каой
				result[result.length-1].type = 'move';
				result[result.length-1].vector = 'ld';
				if(fig.id == games[gId].id1){
					result[result.length-1].angle = 225;					
				} else if(fig.id == games[gId].id2){
					result[result.length-1].angle = 45;
				}
			}else if(games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == fig.id) {
				result[result.length-1].type = 'support'; 
				result[result.length-1].vector = 'ld';
				break;
			} else {
				result[result.length-1].type = 'attack';
				result[result.length-1].vector = 'ld';
				break;
			}
		}
	}

	for(var rr = 1; rr<= fig.moveRadius; rr+=1){
		if(gorz+rr <= ww && vert-rr >= 1){//справа низ
			result.push({});
			result[result.length-1].coord = String.fromCharCode(64+vert-rr) + ':' + (gorz+rr).toString();
			if( games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == null){//пиздец каой
				result[result.length-1].type = 'move';
				result[result.length-1].vector = 'rd';
				if(fig.id == games[gId].id1){
					result[result.length-1].angle = 135;					
				} else if(fig.id == games[gId].id2){
					result[result.length-1].angle = 315;
				}
			}else if(games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == fig.id) {
				result[result.length-1].type = 'support'; 
				result[result.length-1].vector = 'rd';
				break;
			} else {
				result[result.length-1].type = 'attack';
				result[result.length-1].vector = 'rd';
				break;
			}
		}
	}

}

//  матрица хода I
function moveMatrixI(gId, fig, result){
	var ww = games[gId].field.w;
	var hh = games[gId].field.h;
	
	//var num = coord_toInx(fig.coord, ww, hh);

	if(fig.coord.length>3){
		var gorz=parseInt(fig.coord[2]+fig.coord[3], 10);
	} else {
		var gorz=parseInt(fig.coord[2], 10);
	}

	var vert =  fig.coord[0].charCodeAt(0)-64;


	//	fixme много одинакового кодаа! Зафигачить фцию и нырять в неё
	for(var rr = 1; rr<= fig.moveRadius; rr+=1){ 
		if(gorz+rr <= ww){//справа
			result.push({});
			result[result.length-1].coord = (fig.coord[0] + ':' + (gorz+rr).toString());
			if( games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == null){//fixme вывести в консоль и глянуть 
				result[result.length-1].type = 'move';
				result[result.length-1].vector = 'r';
				if(fig.id == games[gId].id1){
					result[result.length-1].angle = 90;					
				} else if(fig.id == games[gId].id2){
					result[result.length-1].angle = 270;
				}
			} else if(games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == fig.id) {
				result[result.length-1].type = 'support'; 
				result[result.length-1].vector = 'r';
				break;
			} else {
				result[result.length-1].type = 'attack';
				result[result.length-1].vector = 'r';
				break;
			}
		}
	}

	for(var rr = 1; rr<= fig.moveRadius; rr+=1){ 
		if(gorz-rr >= 1){//слева
			result.push({});
			result[result.length-1].coord = (fig.coord[0] + ':' + (gorz-rr).toString());
			if( games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == null){//пиздец каой
				result[result.length-1].type = 'move';
				result[result.length-1].vector = 'l';
				if(fig.id == games[gId].id1){
					result[result.length-1].angle = 270;					
				} else if(fig.id == games[gId].id2){
					result[result.length-1].angle = 90;
				} 
			} else if(games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == fig.id) {
				result[result.length-1].type = 'support'; 
				result[result.length-1].vector = 'l';
				break;
			} else {
				result[result.length-1].type = 'attack';
				result[result.length-1].vector = 'l';
				break;
			}
		}
	}

	for(var rr = 1; rr<= fig.moveRadius; rr+=1){ 
		if(vert+rr <= hh){//сверху
			result.push({});
			result[result.length-1].coord = (String.fromCharCode(64+vert+rr) + ':' + gorz.toString());
			if( games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == null){//пиздец каой
				result[result.length-1].type = 'move';
				result[result.length-1].vector = 'u';
				if(fig.id == games[gId].id1){
					result[result.length-1].angle = 0;					
				} else if(fig.id == games[gId].id2){
					result[result.length-1].angle = 180;
				}
			}else if(games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == fig.id) {
				result[result.length-1].type = 'support'; 
				result[result.length-1].vector = 'u';
				break;
			} else {
				result[result.length-1].type = 'attack';
				result[result.length-1].vector = 'u';
				break;
			}
		}
	}

	for(var rr = 1; rr<= fig.moveRadius; rr+=1){ 
		if(vert-rr >= 1){//снизу
			result.push({});
			result[result.length-1].coord = (String.fromCharCode(64+vert-rr) + ':' + gorz.toString());
			if( games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == null){//пиздец каой
				result[result.length-1].type = 'move';
				result[result.length-1].vector = 'd';
				if(fig.id == games[gId].id1){
					result[result.length-1].angle = 180;					
				} else if(fig.id == games[gId].id2){
					result[result.length-1].angle = 0;
				}
			}else if(games[gId].field.tile[coord_toInx(result[result.length-1].coord, ww, hh)].vacant == fig.id) {
				result[result.length-1].type = 'support'; 
				result[result.length-1].vector = 'd';
				break;
			} else {
				result[result.length-1].type = 'attack';
				result[result.length-1].vector = 'd';
				break;
			}
		}
	}

}

//////////////////
//	ПЕРЕКЛ ХОДА
/////////////////

function nextTurn(gId){
	if(games[gId].turn == games[gId].id1){
		games[gId].turn = games[gId].id2;
	} else if(games[gId].turn == games[gId].id2){
		games[gId].turn = games[gId].id1;
	}
}

// координаты в индекс
function coord_toInx(a1, w, h){

  if(a1.length>3){
    var ww = parseInt(a1[2]+a1[3], 10);  
  }else{
    var ww = parseInt(a1[2], 10);
  }
  var hh = a1[0].charCodeAt(0)-64;

  return (hh-1)*w + ww;

}

// переключение клетка свободна/нет прописываем в клетку индекс фигуры
function toggleVacant(gId, coord, idd, figInx){
	var num = coord_toInx(coord, games[gId].field.w, games[gId].field.h);

	if(games[gId].field.tile[num].vacant == null){ //fixme булёвы заменить на null/id1/id2
		games[gId].field.tile[num].vacant = idd;
		games[gId].field.tile[num].figInx = figInx;
	} else if(games[gId].field.tile[num].vacant == idd) {
		games[gId].field.tile[num].vacant = null; //если наступаешь на фигуру, вызывать ф-цию 2 раза?
		games[gId].field.tile[num].figInx = null;
	} else {
		games[gId].field.tile[num].vacant = idd;
		games[gId].field.tile[num].figInx = figInx;
	}

	//console.log(games[gId].field.tile[num].coord + ' - ' + games[gId].field.tile[num].vacant);
}

///////////////////////
//	ФИГУРЫ - ЭКШОН
///////////////////////
eurecaServer.exports.mrkDown = function(gId, idd, inx){
	
	var remote =  eurecaServer.getClient(idd);
	remote.ungetMarkers();

	// fixme проверка на тип маркера нужна if(markers[inx].type == 'move') итэдэ

	if(games[gId].markers[inx].type == 'move'){
		toggleVacant(gId, games[gId].figure[games[gId].figureOnClick].coord, idd, games[gId].figureOnClick);//освобождаем
		toggleVacant(gId, games[gId].markers[inx].coord, idd, games[gId].figureOnClick);//занимаем

		games[gId].figure[games[gId].figureOnClick].coord = games[gId].markers[inx].coord;
		
		remote = eurecaServer.getClient(games[gId].id1);
		remote.getFigureMove(games[gId].figureOnClick, games[gId].markers[inx].coord);
		
		remote = eurecaServer.getClient(games[gId].id2);
		remote.getFigureMove(games[gId].figureOnClick, games[gId].markers[inx].coord);

	} else if(games[gId].markers[inx].type == 'support'){
		// оттут пока хз. как вариант - убрать пока из клиента
	} else if(games[gId].markers[inx].type == 'attack'){
		//считаем атаку-защищаку
		var attInx = games[gId].figureOnClick; //inx 1
		var defInx = games[gId].field.tile[coord_toInx(games[gId].markers[inx].coord, games[gId].field.w, games[gId].field.h)].figInx; //inx2

		//	уменьшаем хп
		games[gId].figure[defInx].health -= games[gId].figure[attInx].attack;
		
		games[gId].figure[attInx].health -= games[gId].figure[defInx].attack;

		//проверяем умер или нет атакующий
		if(games[gId].figure[attInx].health<=0){
			killFigure(gId, attInx);
		} else {
			//	врубать это только если юнит ближнего боя
			var tc = games[gId].figure[defInx].coord
			 
			switch (games[gId].markers[inx].vector) { // кто блять придумал синтаксис свитча? ни раздела строк, нихуя бля! чорт ногу сломит
				case 'r': 
					//	предусмотреть двузначное число
					games[gId].figure[attInx].coord = tc[0]+tc[1]+ (parseInt(tc[2], 10)-1).toString();
					// перекл клэтки
					break
				case 'l': 
					break
				case 'u': 
					break
				case 'd': 
					break
				case 'ru':
					break
				case 'lu':
					break
				case 'rd':
					break
				case 'ld':
					break
			}
		}

		//проверяем умер или нет защищающийся

		//если после атаки оба остаются в живых, 
		//то перемещаем атакера на максимально близкое расстояние. КАК?

		// kill this:
		//toggleVacant(gId, games[gId].figure[games[gId].figureOnClick].coord, idd, games[gId].figureOnClick);//освобождаем
		//toggleVacant(gId, games[gId].markers[inx].coord, idd, games[gId].figureOnClick);//занимаем

		//games[gId].figure[games[gId].figureOnClick].coord = games[gId].markers[inx].coord;

		//	fixme координаты забыл передать, ёбана! В getFigureAttack  проверять координаты прост, и выполнять две анимации
		remote = eurecaServer.getClient(games[gId].id1);
		remote.getFigureAttack(attInx, games[gId].figure[attInx].coord, games[gId].figure[attInx].health, defInx, games[gId].figure[defInx].coord, games[gId].figure[defInx].health);
		
		remote = eurecaServer.getClient(games[gId].id2);
		remote.getFigureAttack(attInx, games[gId].figure[attInx].coord, games[gId].figure[attInx].health, defInx, games[gId].figure[defInx].coord, games[gId].figure[defInx].health);
		
	}

	games[gId].markers.length = 0;
	games[gId].figureOnClick = null;

	//console.log(games[gId].field.tile[1].coord + ' - ' + games[gId].field.tile[1].vacant);

	//for (var ii=1; ii<games[gId].field.tile.length+1; ii+=1){
	//	console.log(ii + '-' + games[gId].field.tile[ii].vacant);
	//}

	nextTurn(gId);

}

//	ШМЕРТЬ
function killFigure(gId, inx){
	//	освободить клэтку
	toggleVacant(gId, games[gId].figure[inx].coord, games[gId].figure[inx].id, inx);

	//	координаты в 0:0
	games[gId].figure[inx].coord = '0:0';

	//	объяснить клиенту, что фигура мертва // нужна последовательность
}



/////////////////////
// SORT AND CLEAN WAIT ARRAY
/////////////////////
function sortAndClean(){
	clientsWait.length = 0; // fixme охуеть как фикс ми!
}

/////////////////////
// CHAT
/////////////////////
eurecaServer.exports.say = function(gId, enId, msg){	
	var remote = eurecaServer.getClient(enId)
	remote.chat(messages[msg]);// fixme / from db or JSON
}

/////////////////////
//detect client disconnection
/////////////////////
eurecaServer.onDisconnect(function (conn){
	// body...
	console.log('Client disconnected', conn.id);

	var removeId = clients[conn.id].id;
	
	delete clients[conn.id];
	
	for (var c in clients)
	{
		var remote = clients[c].remote;
		
		//here we call kill() method defined in the client side
		remote.kill(conn.id);
	}
});

/////////////////////
// пустая херь пока
/////////////////////
eurecaServer.exports.handshake = function(){
	//var conn = this.connection;
	for (var c in clients)
	{
		var remote = clients[c].remote;
		for (var cc in clients)
		{		
			remote.spawnEnemy(clients[cc].id, 0, 0);		
		}
	}
}

/////////////////////
// DATABASE чек по ЕМАЙЛу
/////////////////////
eurecaServer.exports.checkLogin = function(con, eml, pwd){
	console.log(eml + ' : ' + pwd);
	var remote = eurecaServer.getClient(con);

	//dbConnection.connect;
	dbConnection.query('SELECT * from users WHERE mail = '+ '"' + eml + '"', function(err, rows) {
		if(rows.length != 0){
	    	console.log(rows[0].mail);
	    	if(rows[0].pass == pwd){
	    		clients[con].baseId = rows.id;
	    		console.log('password right');
	    		remote.loginAnswer('yes');
	    		//return('yes');
	    	} else {
				console.log('Wrong password or email');
				//return('Wrong password or email');
				remote.loginAnswer('nope');
	    	}

		} else {
			console.log('Wrong password or email');
			//return('Wrong password or email');
			remote.loginAnswer('nope');
		}
		
	});
	//dbConnection.end(); // fixme крашится при этом почемуто бля

}



server.listen(8000);